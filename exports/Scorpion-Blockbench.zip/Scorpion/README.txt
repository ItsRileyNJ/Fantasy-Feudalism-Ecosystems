SCORPION — EDITABLE BLOCKBENCH PROJECT

Open Scorpion.bbmodel in Blockbench using File > Open Model.
The current 0.1.54 model, texture mapping, bone pivots and resting tail pose are included. The texture is embedded, so the .bbmodel works by itself. A separate scorpion.png is also included for texture editing.

Use the Edit and Paint tabs to make changes. Keep the groups and hierarchy when possible so the existing leg, pincer and tail animations can be retained. Save as .bbmodel and send the edited file back for integration.

The mod's procedural walking, idle and sting animations remain in the Java code; they are not keyframed animations in this project. The full joint hierarchy is preserved for editing.

source_map.json links the exported group UUIDs to the native model bones for re-import. You do not need to edit it.

No commit or push was made.
